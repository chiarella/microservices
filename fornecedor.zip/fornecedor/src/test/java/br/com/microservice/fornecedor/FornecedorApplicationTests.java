package br.com.microservice.fornecedor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FornecedorApplicationTests {

	@Test
	void contextLoads() {
	}

}
